const url = "http://localhost:5000";
const show_all_writers = url + "/api/writers";
const show_all_books = url + "/api/books";

// POST
const add_book = url + "/api/books";

// POST
const add_writer = url + "/api/writers";

export { url, show_all_writers, show_all_books, add_writer, add_book };
