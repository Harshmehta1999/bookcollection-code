import React, { Component } from "react";

const quickStyle = { marginTop: "2%", textAlign: "center" };
const crimsonStyle = { color: "crimson" };

export default class ViewBook extends Component {
  render() {
    return (
      <div style={quickStyle}>
        <h2>View Book Details:</h2>
        <span>Use this id to look up the details for this book : </span>
        <span style={crimsonStyle}>{this.props.id}</span>
      </div>
    );
  }
}
