import React, { Component } from "react";
import { Button } from "reactstrap";
import Axios from "axios";
import * as UTILS from "../utils";
import WritersSelector from "./WritersSelector";

export default class AddBook extends Component {
  constructor(props) {
    super(props);
    this.formRef = React.createRef();
    this.state = { author_id: 0 };
  }

  onWriterUpdated = e => {
    this.setState({ author_id: e.target.value });
  };

  addBook = e => {
    e.preventDefault();

    var formData = new FormData(this.formRef.current);
    // could do this OR use the hidden input
    // formData.append("author_id", this.state.author_id);

    Axios.post(UTILS.add_book, formData).then(res => {
      console.log(res);
    });
  };
  render() {
    return (
      <div style={{ width: "60vw", margin: "0 auto" }}>
        <WritersSelector onWriterUpdated={this.onWriterUpdated} />

        <form onSubmit={this.addBook} ref={this.formRef}>
          <label>Title</label>
          <input type="text" name="title" placeholder="Book Title" />

          <label>Pages</label>
          <input type="number" name="pages" placeholder="pages" min="1" />

          <label>ISBN</label>
          <input
            type="text"
            name="isbn"
            placeholder="ISBN Number"
            min="1"
            max="13"
          />

          <input type="hidden" name="author_id" value={this.state.author_id} />

          {/* reactstrap button - UPPERCASE */}
          <Button type="submit">Submit</Button>
        </form>
      </div>
    );
  }
}
